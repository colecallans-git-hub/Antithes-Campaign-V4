#stronghold 
[[Ūdeth]]
