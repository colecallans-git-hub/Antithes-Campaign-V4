# Worldbuilding

Detailed notes will go here.